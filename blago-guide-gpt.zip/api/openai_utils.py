
import openai, os

def ask_gpt(message: str) -> str:
    model = os.getenv("GPT_MODEL_ID")
    response = openai.ChatCompletion.create(
        model=model,
        messages=[{"role": "user", "content": message}]
    )
    return response['choices'][0]['message']['content']
