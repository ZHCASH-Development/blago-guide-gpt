
from telegram import Update
from telegram.ext import ApplicationBuilder, CommandHandler, ContextTypes
import openai, os

openai.api_key = os.getenv("OPENAI_API_KEY")
GPT_MODEL = os.getenv("GPT_MODEL_ID")

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("Привет! Я BlagoGUIDE, ассистент по системе БлагоДар.")

app = ApplicationBuilder().token(os.getenv("TELEGRAM_TOKEN")).build()
app.add_handler(CommandHandler("start", start))
app.run_polling()
