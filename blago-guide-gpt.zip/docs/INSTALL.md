
# Установка BlagoGUIDE GPT

1. Клонируйте репозиторий:
```bash
git clone https://github.com/ZHCASH-Development/blago-guide-gpt.git
cd blago-guide-gpt
```

2. Установите зависимости:
```bash
pip install -r requirements.txt
```

3. Создайте файл `.env` по примеру `.env.example`

4. Запустите бота:
```bash
python bot/main.py
```
